package pessoa;

public class Pessoa {
    private String nome;
    private String contato1;
    private String contato2;
    
    
    public Pessoa(String nome){
        this.nome = nome;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the contato1
     */
    public String getContato1() {
        return contato1;
    }

    /**
     * @param contato1 the contato1 to set
     */
    public void setContato1(String contato1) {
        this.contato1 = contato1;
    }

    /**
     * @return the contato2
     */
    public String getContato2() {
        return contato2;
    }

    /**
     * @param contato2 the contato2 to set
     */
    public void setContato2(String contato2) {
        this.contato2 = contato2;
    }
}
