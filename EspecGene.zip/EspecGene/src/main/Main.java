package main;

import cliente.ClienteFisico;
import cliente.ClienteJuridico;

/**
 *
 * @author LABORATORIO 01
 */
public class Main {
    public static void main(String[] args) {
       ClienteFisico clif = new ClienteFisico("Alan", "074.879.987-78");
       ClienteJuridico clij = new ClienteJuridico("Alan Pery CIA LTDA", "987.789.789/0001.40");
       
       ContaFisico cf = new ContaFisico(clif, "svg", "sfgs");
       
        System.out.println(clif.getNome());
        System.out.println(clif.getCpf());
        
        System.out.println(clij.getCnpj());
        System.out.println(clij.getRazaoSocial());
       
    }
}
