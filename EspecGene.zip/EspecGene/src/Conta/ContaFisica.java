package Conta;

import cliente.ClienteFisico;

public class ContaFisica extends Conta{
    private ClienteFisico cliente;
    
    public ContaFisica(ClienteFisico cliente, String conta, String agencia){
        super(conta, agencia);
        this.cliente = cliente;
    }

    /**
     * @return the cliente
     */
    public ClienteFisico getCliente() {
        return cliente;
    }

    /**
     * @param cliente the cliente to set
     */
    public void setCliente(ClienteFisico cliente) {
        this.cliente = cliente;
    }
}
