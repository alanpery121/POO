package Conta;

public class Conta {
    private String numConta;
    private String numAgencia;
    
    public Conta(String numConta, String numAgencia){
        this.numConta = numConta;
        this.numAgencia = numAgencia;
    }

    /**
     * @return the numConta
     */
    public String getNumConta() {
        return numConta;
    }

    /**
     * @param numConta the numConta to set
     */
    public void setNumConta(String numConta) {
        this.numConta = numConta;
    }

    /**
     * @return the numAgencia
     */
    public String getNumAgencia() {
        return numAgencia;
    }

    /**
     * @param numAgencia the numAgencia to set
     */
    public void setNumAgencia(String numAgencia) {
        this.numAgencia = numAgencia;
    }
    
    
}
