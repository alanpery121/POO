package conta;

/**
 *
 * @author LABORATORIO 01
 */
public class Conta {
    private String numeroConta;
    private String numeroAgencia;
    private double saldo;
    private String senhaConta;
    private String situacaoConta;
    
    public Conta(String numeroConta, String numeroAgencia){
        this.numeroConta = numeroConta;
        this.numeroAgencia = numeroAgencia;
    }
    
    public void deposito(Conta c1, double saldo){
        if(saldo > 0){
            c1.saldo += saldo;
            System.out.println("Deposito realizado com sucesso!");
            System.out.println("Novo saldo"+c1.saldo);
        }
}

    /**
     * @return the numeroConta
     */
    public String getNumeroConta() {
        return numeroConta;
    }

    /**
     * @param numeroConta the numeroConta to set
     */
    public void setNumeroConta(String numeroConta) {
        this.numeroConta = numeroConta;
    }

    /**
     * @return the numeroAgencia
     */
    public String getNumeroAgencia() {
        return numeroAgencia;
    }

    /**
     * @param numeroAgencia the numeroAgencia to set
     */
    public void setNumeroAgencia(String numeroAgencia) {
        this.numeroAgencia = numeroAgencia;
    }

    /**
     * @return the saldo
     */
    public double getSaldo() {
        return saldo;
    }

    /**
     * @return the senhaConta
     */
    public String getSenhaConta() {
        return senhaConta;
    }

    /**
     * @param senhaConta the senhaConta to set
     */
    public void setSenhaConta(String senhaConta) {
        this.senhaConta = senhaConta;
    }

    /**
     * @return the situacaoConta
     */
    public String getSituacaoConta() {
        return situacaoConta;
    }

    /**
     * @param situacaoConta the situacaoConta to set
     */
    public void setSituacaoConta(String situacaoConta) {
        this.situacaoConta = situacaoConta;
    }
}
