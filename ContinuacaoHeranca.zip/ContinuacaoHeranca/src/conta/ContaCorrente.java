package conta;

/**
 *
 * @author LABORATORIO 01
 super é do java*/
public class ContaCorrente extends Conta{
    private double porcentagemImpostoMensal;

    public ContaCorrente(String conta, String agencia, double pc){
        super(conta, agencia);
        this.porcentagemImpostoMensal = pc;
    }

    /**
     * @return the porcentagemImpostoMensal
     */
    public double getPorcentagemImpostoMensal() {
        return porcentagemImpostoMensal;
    }

    /**
     * @param porcentagemImpostoMensal the porcentagemImpostoMensal to set
     */
    public void setPorcentagemImpostoMensal(double porcentagemImpostoMensal) {
        this.porcentagemImpostoMensal = porcentagemImpostoMensal;
    }
}
