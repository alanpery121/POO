/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package funcionario;

/**
 *
 * @author ALAN
 */
public class Supervisor extends Funcionario{
    private boolean GerarRelatorio;

    /**
     * @return the GerarRelatorio
     */
    public boolean getGerarRelatorio() {
        return GerarRelatorio;
    }

    /**
     * @param GerarRelatorio the GerarRelatorio to set
     */
    public void setGerarRelatorio(boolean GerarRelatorio) {
        this.GerarRelatorio = GerarRelatorio;
    }
}
