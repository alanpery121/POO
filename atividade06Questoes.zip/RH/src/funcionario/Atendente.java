/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package funcionario;

/**
 *
 * @author ALAN
 */
public class Atendente extends Funcionario{
    private String Agenda;

    /**
     * @return the Agenda
     */
    public String getAgenda() {
        return Agenda;
    }

    /**
     * @param Agenda the Agenda to set
     */
    public void setAgenda(String Agenda) {
        this.Agenda = Agenda;
    }
}
