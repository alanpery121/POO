/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package funcionario;

/**
 *
 * @author ALAN
 */
public class Funcionario {
    private String nome;
    private double salario;
    private double percentual;

    
    
    
    public double CalcDescINSS(double salario){
        return this.salario = salario;
    }
    public double CalcDescINSS(double salario, double percentual){
        return salario - (salario * percentual);
    }
    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the salario
     */
    public double getSalario() {
        return salario;
    }

    /**
     * @param salario the salario to set
     */
    public void setSalario(double salario) {
        this.salario = salario;
    }

    /**
     * @return the percentual
     */
    public double getPercentual() {
        return percentual;
    }

    /**
     * @param percentual the percentual to set
     */
    public void setPercentual(double percentual) {
        this.percentual = percentual;
    }
    
    
}
