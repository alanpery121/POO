/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package funcionario;

/**
 *
 * @author ALAN
 */
public class Balconista extends Funcionario{
    private boolean acessoVendas;

    /**
     * @return the acessoVendas
     */
    public boolean getAcessoVendas() {
        return acessoVendas;
    }

    /**
     * @param acessoVendas the acessoVendas to set
     */
    public void setAcessoVendas(boolean acessoVendas) {
        this.acessoVendas = acessoVendas;
    }
}
