/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import funcionario.Atendente;
import funcionario.Balconista;
import funcionario.Supervisor;

/**
 *
 * @author ALAN
 */
public class Main {
    public static void main(String[] args) {
     Supervisor sp = new Supervisor();
     System.out.println("Supervisor");
     sp.setNome("Alan");
     sp.setGerarRelatorio(true);
     sp.setSalario(2000);
     System.out.println("Nome supervisor" + sp.getNome());
     System.out.println("Slario" + sp.getSalario());
     System.out.println("Permissão para gerar relatorio" + sp.getGerarRelatorio());
     System.out.println("O percentualde desc. é:" + sp.CalcDescINSS(0.11));
     System.out.println("---------------------------------");
    
        Atendente at = new Atendente();
        System.out.println("Atendente");
        at.setNome("jubileu");
        at.setAgenda("De segunda a sexta");
        System.out.println("Nome supervisor" + at.getNome());
        System.out.println("Slario" + at.getSalario());
        System.out.println("Dias de agendaento" + at.getAgenda());
        System.out.println("O salario como o desconto do INSS" + at.CalcDescINSS(998, 0.08));
        System.out.println("---------------------------------");
        
        Balconista b = new Balconista();
        System.out.println("Balconista");
        b.setNome("jubileu");
        b.setAcessoVendas(true);
        System.out.println("Nome supervisor" + b.getNome());
        System.out.println("Slario" + b.getSalario());
        System.out.println("Permissao para efetuar vendas" + b.getAcessoVendas());
        System.out.println("O salario como o desconto do INSS" + b.CalcDescINSS(998, 0.08));
        System.out.println("---------------------------------");
        
        
        
    }
}
