/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concessionaria02;

/**
 *
 * @author ALAN
 */
public class Fusca extends Carro{
    private String qtdQuilometrosRodados;
            
        private double calcularIPVA(double valorVenalFusca, double valorAliquotaFusca){
        return valorVenalFusca * valorAliquotaFusca;
    }
            
  public Fusca( String modelo){
    
}
    public Fusca(String modelo, String ano){
        
    }
    public Fusca(String modelo, String ano, String qtdQuilometrosRodados){
        
    }  

    /**
     * @return the qtdQuilometrosRodados
     */
    public String getQtdQuilometrosRodados() {
        return qtdQuilometrosRodados;
    }

    /**
     * @param qtdQuilometrosRodados the qtdQuilometrosRodados to set
     */
    public void setQtdQuilometrosRodados(String qtdQuilometrosRodados) {
        this.qtdQuilometrosRodados = qtdQuilometrosRodados;
    }
}
