/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concessionaria02;

/**
 *
 * @author ALAN
 */
public class Fiat extends Carro{
    private String cor;
    
    private double calcularIPVA(double valorVenalFiat, double valorAliquotaFiat){
        return valorVenalFiat * valorAliquotaFiat;
    }
    
    public Fiat( String modelo){
    
}
    public Fiat(String modelo, String ano){
        
    }
    public Fiat(String modelo, String ano, String cor){
        
    }

    /**
     * @return the cor
     */
    public String getCor() {
        return cor;
    }

    /**
     * @param cor the cor to set
     */
    public void setCor(String cor) {
        this.cor = cor;
    }
}
