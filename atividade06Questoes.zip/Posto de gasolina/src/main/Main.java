/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import postoDeGasolina.AuxiliarAdm;
import postoDeGasolina.Frentista;
import postoDeGasolina.Supervisor;

/**
 *
 * @author ALAN
 */
public class Main {
    public static void main(String[] args) {
        Supervisor sp = new Supervisor();
    
    System.out.println("Supervisor");
    sp.setNome("Alan");
    sp.setGerarRelatorio("Toda semana");
    System.out.println("Nome supervisor" + sp.getNome());
    System.out.println("Gerar relatorio"+ sp.getGerarRelatorio());
    System.out.println("Salario com o desconto do INSS" + sp.CalcDescINSS(2.400, 0.11));
    
    Frentista f = new Frentista();
    System.out.println("Frentista");
    f.setNome("Alan");
    f.setQTDAtendimento("80");
    System.out.println("Nome supervisor" + f.getNome());
    System.out.println("Quantidade atendimento"+ f.getQTDAtendimento());
    System.out.println("Salario com o desconto do INSS" + f.CalcDescINSS(1.100, 0.08));
    
    AuxiliarAdm aa = new AuxiliarAdm();
    System.out.println("Auxiliar   Administrativo");
    aa.setNome("Alan");
    aa.setTiposDocumentosDigitados("Documnetos alvara...");
    System.out.println("Nome supervisor" + aa.getNome());
    System.out.println("GTipos de documentos para digitar"+ aa.getTiposDocumentosDigitados());
    System.out.println("Salario com o desconto do INSS" + aa.CalcDescINSS(1.700, 0.11));
    
    }
}
