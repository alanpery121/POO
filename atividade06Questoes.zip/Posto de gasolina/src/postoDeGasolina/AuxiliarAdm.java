/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package postoDeGasolina;

/**
 *
 * @author ALAN
 */
public class AuxiliarAdm extends Funcionario{
    private String tiposDocumentosDigitados;

    /**
     * @return the tiposDocumentosDigitados
     */
    public String getTiposDocumentosDigitados() {
        return tiposDocumentosDigitados;
    }

    /**
     * @param tiposDocumentosDigitados the tiposDocumentosDigitados to set
     */
    public void setTiposDocumentosDigitados(String tiposDocumentosDigitados) {
        this.tiposDocumentosDigitados = tiposDocumentosDigitados;
    }
}
