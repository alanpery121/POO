/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package postoDeGasolina;

/**
 *
 * @author ALAN
 */
public class Frentista extends Funcionario{
    private String QTDAtendimento;
    

    /**
     * @return the QTDAtendimento
     */
    public String getQTDAtendimento() {
        return QTDAtendimento;
    }

    /**
     * @param QTDAtendimento the QTDAtendimento to set
     */
    public void setQTDAtendimento(String QTDAtendimento) {
        this.QTDAtendimento = QTDAtendimento;
    }
}
