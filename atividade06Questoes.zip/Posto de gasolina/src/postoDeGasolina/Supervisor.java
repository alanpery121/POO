/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package postoDeGasolina;

/**
 *
 * @author ALAN
 */
public class Supervisor extends Funcionario{
    private String gerarRelatorio;

    /**
     * @return the gerarRelatorio
     */
    public String getGerarRelatorio() {
        return gerarRelatorio;
    }

    /**
     * @param gerarRelatorio the gerarRelatorio to set
     */
    public void setGerarRelatorio(String gerarRelatorio) {
        this.gerarRelatorio = gerarRelatorio;
    }
}
