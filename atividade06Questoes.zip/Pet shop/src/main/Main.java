/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import animal.Animal;
import animal.Cachorro;
import animal.Galinha;
import animal.Gato;

/**
 *
 * @author ALAN
 */
public class Main {
    
    public static void fazerBarulho(Animal animal){
        animal.ruido();
    }
    
    public static void main(String[] args) {
        
    Animal animal = new Animal();
    Gato gato = new Gato();
    Cachorro cachorro = new Cachorro();
    Galinha galinha = new Galinha();
    
    gato.ruido();
    cachorro.ruido();
    galinha.ruido();
    
    
    fazerBarulho(animal);
    }
}
