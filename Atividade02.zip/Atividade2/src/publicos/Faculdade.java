package publicos;

/**
 *
 * @author ALAN
 */
public class Faculdade {
    public String qtdSala;
    public String diretor;
    public String qtdFuncionarios;
    public String qtdProfessores;
}
