package publicos;

/**
 *
 * @author ALAN
 */
public class Moto {
    public String modelo;
    public String ano;
    public String qtdPeneus;
    public String qtdMarcha;
}
