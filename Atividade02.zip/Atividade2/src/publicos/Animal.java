package publicos;

/**
 *
 * @author ALAN
 */
public class Animal {
    public String especie;
    public String sexo;
    public boolean pelo;
    public boolean presa;
}
