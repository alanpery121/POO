package publicos;

/**
 *
 * @author ALAN
 */
public class Pessoa {
    public String nome;
    public String cpf;
    public String rg;
    public boolean vivo;

}
