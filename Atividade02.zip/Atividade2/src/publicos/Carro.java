package publicos;

/**
 *
 * @author ALAN
 */
public class Carro {
    public String modelo;
    public String ano;
    public String qtdPeneus;
    public String qtdBancos;
}
