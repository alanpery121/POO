package publicos;

/**
 *
 * @author ALAN
 */
public class Principal {

    public static void main(String[] args) {
        Animal a1 = new Animal();
        Carro c1 = new Carro();
        Faculdade f1 = new Faculdade();
        Moto m1 = new Moto();
        Pessoa p1 = new Pessoa();
        
        a1.especie = "Gato";
        a1.sexo = "Macho";
        a1.pelo = true;
        a1.presa = true;
        
        System.out.println(a1.especie+"\n"+a1.sexo+"\n"+a1.presa+"\n"+a1.pelo);
        
        
        c1.ano = "2019";
        c1.modelo= "logan";
        c1.qtdBancos = "4";
        c1.qtdPeneus = "4";
        
        System.out.println(c1.ano+"\n"+c1.modelo+"\n"+c1.qtdBancos+"\n"+c1.qtdPeneus);
        
        
        f1.diretor= "Alan";
        f1.qtdProfessores = "30";
        f1.qtdFuncionarios = "90";
        f1.qtdSala = "25";
        
        System.out.println(f1.diretor+"\n"+f1.qtdProfessores+"\n"+f1.qtdFuncionarios+"\n"+f1.qtdSala);
        
        
        m1.ano = "2019";
        m1.modelo= "broz";
        m1.qtdMarcha = "4";
        m1.qtdPeneus = "2";
        
        System.out.println(m1.ano+"\n"+m1.modelo+"\n"+m1.qtdMarcha+"\n"+m1.qtdPeneus);
        
        
        p1.nome = "Alan";
        p1.cpf = "076.234.432-12";
        p1.rg = "1234567789";
        p1.vivo = true;
        
        System.out.println(p1.nome+"\n"+p1.cpf+"\n"+p1.rg+"\n"+p1.vivo);
    }
    
}
