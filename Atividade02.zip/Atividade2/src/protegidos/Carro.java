package protegidos;

/**
 *
 * @author ALAN
 */
public class Carro {
    protected String modelo;
    protected String ano;
    protected String qtdPeneus;
    protected String qtdBancos;
}
