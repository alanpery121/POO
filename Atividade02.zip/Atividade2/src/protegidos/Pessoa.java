package protegidos;

/**
 *
 * @author ALAN
 */
public class Pessoa {
    protected String nome;
    protected String cpf;
    protected String rg;
    protected boolean vivo;
}
