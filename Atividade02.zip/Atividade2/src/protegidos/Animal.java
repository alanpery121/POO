package protegidos;

/**
 *
 * @author ALAN
 */
public class Animal {
    protected String especie;
    protected String sexo;
    protected boolean pelo;
    protected boolean presa;
}
