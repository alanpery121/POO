/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurante;

/**
 *
 * @author ALAN
 */
public class Principal {
    public static void main(String[] args) {
        Cliente c1 = new Cliente();
        Cozinheira cz1 = new Cozinheira();
        Garcon g1 = new Garcon();
        Gerente gr1 = new Gerente();
        Proprietario p1= new Proprietario();
        
        c1.conta = "200 reais";
        c1.nome = "Danylo";
        c1.mesa = "3";
        c1.cpf = "123.456.789-10";
        
        System.out.println(c1.conta+"\n"+c1.nome+"\n"+c1.mesa+"\n"+c1.cpf);
        
        cz1.nome = "Victor";
        cz1.cpf = "102.345.345.-22";
        cz1.salario = "500 Reais";
        cz1.turno = "Tarde";
        
        System.out.println(cz1.nome+"\n"+cz1.cpf+"\n"+cz1.salario+"\n"+cz1.turno);
        
        
        g1.nome = "Caio";
        g1.cpf = "423.232.232-22";
        g1.salario = "400 reias";
        g1.turno = "Tarde";
        
        System.out.println(g1.nome+"\n"+g1.cpf+"\n"+g1.salario+"\n"+g1.turno);
        
        gr1.nome = "Felipe";
        gr1.cpf = "565.565.565-55";
        gr1.salario = "1.300";
        gr1.turno = "Manha e noite";
        
        System.out.println(gr1.nome+"\n"+gr1.cpf+"\n"+gr1.salario+"\n"+gr1.turno);
        
        
        p1.nome = "Alan";
        p1.cpf = "123.123.123-12";
        p1.salario = "4.000";
        p1.qtdFiliais = "9";
        
        System.out.println(p1.nome+"\n"+p1.cpf+"\n"+p1.salario+"\n"+p1.qtdFiliais);
    }
}
