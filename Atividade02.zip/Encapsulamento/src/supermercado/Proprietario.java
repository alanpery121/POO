/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package supermercado;

/**
 *
 * @author ALAN
 */
public class Proprietario {
    private String nome;
    private String cpf;
    private String qtdFiliais;
    private String salario;

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the cpf
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * @param cpf the cpf to set
     */
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    /**
     * @return the qtdFiliais
     */
    public String getQtdFiliais() {
        return qtdFiliais;
    }

    /**
     * @param qtdFiliais the qtdFiliais to set
     */
    public void setQtdFiliais(String qtdFiliais) {
        this.qtdFiliais = qtdFiliais;
    }

    /**
     * @return the salario
     */
    public String getSalario() {
        return salario;
    }

    /**
     * @param salario the salario to set
     */
    public void setSalario(String salario) {
        this.salario = salario;
    }
}
