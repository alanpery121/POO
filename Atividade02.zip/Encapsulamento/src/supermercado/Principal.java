/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package supermercado;

/**
 *
 * @author ALAN
 */
public class Principal {
    public static void main(String[] args) {
    Atendente a1 = new Atendente();
    Caixa cx1 = new Caixa();
    Cliente c1 = new Cliente();
    Gerente gr1 = new Gerente();
    Proprietario p1= new Proprietario();
    
    a1.setNome("Caio");
    System.out.println(a1.getNome());
    a1.setCpf("123.233");
    System.out.println(a1.getCpf());
    a1.setSalario("300");
    System.out.println(a1.getSalario());
    a1.setTurno("Noite");
    System.out.println(a1.getTurno());
    
    
    cx1.setNome("victor");
    System.out.println(cx1.getNome());
    cx1.setCpf("123.233.345-23");
    System.out.println(cx1.getCpf());
    cx1.setSalario("200");
    System.out.println(cx1.getSalario());
    cx1.setTurno("Noite");
    System.out.println(cx1.getTurno());
    
    gr1.setNome("Danylo");
    System.out.println(gr1.getNome());
    gr1.setCpf("563.234.234-23");
    System.out.println(gr1.getCpf());
    gr1.setSalario("500");
    System.out.println(gr1.getSalario());
    gr1.setTurno("Noite");
    System.out.println(gr1.getTurno());
    
    c1.setNome("felipe");
    System.out.println(c1.getNome());
    c1.setCpf("234.456.567-23");
    System.out.println(c1.getCpf());
    c1.setConta("3000");
    System.out.println(c1.getConta());
    c1.setCartaoFideliade(true);
    
    p1.setNome("ALAN");
    System.out.println(p1.getNome());
    p1.setCpf("123.123.123-12");
    System.out.println(p1.getCpf());
    p1.setSalario("10.000");
    System.out.println(p1.getSalario());
    p1.setQtdFiliais("5");
    System.out.println(p1.getQtdFiliais());
   }
}
