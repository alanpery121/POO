/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package supermercado;

/**
 *
 * @author ALAN
 */
public class Cliente {
   private String nome;
   private String cpf;
   private boolean cartaoFideliade;
   private String conta;

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the cpf
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * @param cpf the cpf to set
     */
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    /**
     * @return the cartaoFideliade
     */
    public boolean getCartaoFideliade() {
        return cartaoFideliade;
    }

    /**
     * @param cartaoFideliade the cartaoFideliade to set
     */
    public void setCartaoFideliade(boolean cartaoFideliade) {
        this.cartaoFideliade = cartaoFideliade;
    }

    /**
     * @return the conta
     */
    public String getConta() {
        return conta;
    }

    /**
     * @param conta the conta to set
     */
    public void setConta(String conta) {
        this.conta = conta;
    }

}
