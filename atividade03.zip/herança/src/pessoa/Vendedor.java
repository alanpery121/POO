/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoa;

/**
 *
 * @author ALAN
 */
public class Vendedor extends Pessoa{
    private boolean metaAlcancada;

    /**
     * @return the metaAlcancada
     */
    public boolean isMetaAlcancada() {
        return metaAlcancada;
    }

    /**
     * @param metaAlcancada the metaAlcancada to set
     */
    public void setMetaAlcancada(boolean metaAlcancada) {
        this.metaAlcancada = metaAlcancada;
    }
}
