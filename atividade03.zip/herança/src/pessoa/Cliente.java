/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoa;

/**
 *
 * @author ALAN
 */
public class Cliente extends Pessoa{
    private String efetuarCompra;

    /**
     * @return the efetuarCompra
     */
    public String getEfetuarCompra() {
        return efetuarCompra;
    }

    /**
     * @param efetuarCompra the efetuarCompra to set
     */
    public void setEfetuarCompra(String efetuarCompra) {
        this.efetuarCompra = efetuarCompra;
    }
}
