package pessoa;

/**
 *
 * @author ALAN
 */
public class Gerente extends Pessoa{
    private String salario;

    /**
     * @return the salario
     */
    public String getSalario() {
        return salario;
    }

    /**
     * @param salario the salario to set
     */
    public void setSalario(String salario) {
        this.salario = salario;
    }
}
