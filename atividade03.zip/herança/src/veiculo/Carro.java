package veiculo;

/**
 *
 * @author ALAN
 */
public class Carro extends Veiculo{
    private String volante;

    /**
     * @return the volante
     */
    public String getVolante() {
        return volante;
    }

    /**
     * @param volante the volante to set
     */
    public void setVolante(String volante) {
        this.volante = volante;
    }
}
