/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package veiculo;

/**
 *
 * @author ALAN
 */
public class Bicicleta extends Veiculo{
    private String qtdPedais;

    /**
     * @return the qtdPedais
     */
    public String getQtdPedais() {
        return qtdPedais;
    }

    /**
     * @param qtdPedais the qtdPedais to set
     */
    public void setQtdPedais(String qtdPedais) {
        this.qtdPedais = qtdPedais;
    }
}
