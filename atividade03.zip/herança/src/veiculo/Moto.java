/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package veiculo;

/**
 *
 * @author ALAN
 */
public class Moto extends Veiculo{
    private String manete;

    /**
     * @return the manete
     */
    public String getManete() {
        return manete;
    }

    /**
     * @param manete the manete to set
     */
    public void setManete(String manete) {
        this.manete = manete;
    }
}
