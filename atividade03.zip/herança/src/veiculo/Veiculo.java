package veiculo;

/**
 *
 * @author ALAN
 */
public class Veiculo {
    private String modelo;
    private String ano;
    private String cor;
    private String qtdPeneus;

    /**
     * @return the modelo
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * @param modelo the modelo to set
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    /**
     * @return the ano
     */
    public String getAno() {
        return ano;
    }

    /**
     * @param ano the ano to set
     */
    public void setAno(String ano) {
        this.ano = ano;
    }

    /**
     * @return the cor
     */
    public String getCor() {
        return cor;
    }

    /**
     * @param cor the cor to set
     */
    public void setCor(String cor) {
        this.cor = cor;
    }

    /**
     * @return the qtdPeneus
     */
    public String getQtdPeneus() {
        return qtdPeneus;
    }

    /**
     * @param qtdPeneus the qtdPeneus to set
     */
    public void setQtdPeneus(String qtdPeneus) {
        this.qtdPeneus = qtdPeneus;
    }
}
