package main;

import pessoa.Cliente;
import pessoa.Gerente;
import pessoa.Vendedor;
import veiculo.Bicicleta;
import veiculo.Carro;
import veiculo.Moto;

/**
 *
 * @author ALAN
 */
public class Main {
    public static void main(String[] args) {
        Gerente g = new Gerente();
        Cliente c = new Cliente();
        Vendedor v = new Vendedor();
        Bicicleta b = new Bicicleta();
        Carro cr = new Carro();
        Moto m = new Moto();
        
        System.out.println("Super Classe Pessoa \n");
        
        c.setEfetuarCompra("true");
        c.setNome("ALAN");
        c.setRg("200865478630");
        c.setSexo("M");
        c.setCpf("045.345.345-30");
        System.out.println(c.getEfetuarCompra()+"\n"+c.getNome()+"\n"+c.getRg()+"\n"+c.getSexo()+"\n"+c.getCpf()+"\n");
        
        

        g.setNome("joao");
        g.setRg("2007865478630");
        g.setSexo("M");
        g.setCpf("123.123.345-30");
        g.setSalario("3000");
        System.out.println(g.getSalario()+"\n"+g.getNome()+"\n"+g.getRg()+"\n"+g.getSexo()+"\n"+g.getCpf()+"\n");
        
        
        v.setNome("Maria");
        v.setRg("200665478630");
        v.setSexo("F");
        v.setCpf("045.345.123-12");
        v.setMetaAlcancada(true);
        System.out.println(v.isMetaAlcancada()+"\n"+v.getNome()+"\n"+v.getRg()+"\n"+v.getSexo()+"\n"+v.getCpf()+"\n");
        
        
        
        System.out.println("Super Classe Viculo \n");
        
        b.setModelo("bike");
        b.setAno("2019");
        b.setQtdPeneus("2");
        b.setCor("branco");
        b.setQtdPedais("2");
        System.out.println(b.getModelo()+"\n"+b.getAno()+"\n"+b.getQtdPeneus()+"\n"+b.getCor()+"\n"+b.getQtdPedais()+"\n");
        
        
        
        cr.setModelo("Prisma");
        cr.setAno("");
        cr.setQtdPeneus("4");
        cr.setCor("Branco");
        cr.setVolante("couro");
        System.out.println(cr.getModelo()+"\n"+cr.getAno()+"\n"+cr.getQtdPeneus()+"\n"+cr.getCor()+"\n"+cr.getVolante()+"\n");
        
        
        m.setModelo("Broz");
        m.setAno("2019");
        m.setQtdPeneus("2");
        m.setCor("Preto");
        m.setManete("123.34");
        System.out.println(m.getModelo()+"\n"+m.getAno()+"\n"+m.getQtdPeneus()+"\n"+m.getCor()+"\n"+m.getManete()+"\n");
    }
}
