/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import Funcionario.Diretor;
import Funcionario.Professor;
import faculdade.FVS;
import faculdade.UniLeao;

/**
 *
 * @author ALAN
 */
public class Main {
    public static void main(String[] args) {
        Diretor d = new Diretor();
        Professor p = new Professor();
        FVS f = new FVS();
        UniLeao u = new UniLeao();
        
        
        
        System.out.println("Funcionario \n");
        
        
        
        d.setNome("Joao");
        d.setSalario(5000);
        d.setCpf("123456789-00");
        d.setFiscalizar("todos os setores");
        d.setHorarioAtendimento("10 horas");
        d.setAdministrar("toda a faculdade");
        System.out.println(d.getNome()+"\n"+d.getSalario()+"\n"+d.getCpf()+"\n"+d.getFiscalizar()+"\n"+d.getHorarioAtendimento()+"\n"+d.getAdministrar()+"\n");
        
        
        
        p.setNome("maria");
        p.setSalario(3000);
        p.setCpf("123123123-12");
        p.setCursoLeciona("ADS");
        p.setGraduacao("analise e desenvolvimento de sistema");
        p.setTurno("noite");
        System.out.println(p.getNome()+"\n"+p.getSalario()+"\n"+p.getCpf()+"\n"+p.getCursoLeciona()+"\n"+p.getGraduacao()+"\n"+p.getTurno()+"\n");
        
         
         
         System.out.println("Faculdade \n");
         
         
         f.setLoalizacao("Icó");
         f.setRazaoSocial("faculdade vale do salgado");
         f.setCnpj("05.234.345/0001.07");
         f.setAcoesSociais(false);
         f.setCursoEAD(true);
         f.setCursosIntegrados(true);
         System.out.println(f.getLoalizacao()+"\n"+f.getRazaoSocial()+"\n"+f.getCnpj()+"\n"+f.isAcoesSociais()+"\n"+f.isCursoEAD()+"\n"+f.isCursosIntegrados());
         
         
         
         u.setLoalizacao("Juazeiro");
         u.setRazaoSocial("");
         u.setCnpj("05.432.543/0001.07");
         u.setSocios("joao, maria, jose");
         u.setFinanciamento(true);
         u.setPrediosAdaptados(true);
         System.out.println(u.getLoalizacao()+"\n"+u.getRazaoSocial()+"\n"+u.getCnpj()+"\n"+u.getSocios()+"\n"+u.isFinanciamento()+"\n"+u.isPrediosAdaptados());
    }
}
