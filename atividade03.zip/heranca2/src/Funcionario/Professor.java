/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Funcionario;

/**
 *
 * @author ALAN
 */
public class Professor extends Funcionario{
    private String turno;
    private String graduacao;
    private String cursoLeciona;

    /**
     * @return the turno
     */
    public String getTurno() {
        return turno;
    }

    /**
     * @param turno the turno to set
     */
    public void setTurno(String turno) {
        this.turno = turno;
    }

    /**
     * @return the graduacao
     */
    public String getGraduacao() {
        return graduacao;
    }

    /**
     * @param graduacao the graduacao to set
     */
    public void setGraduacao(String graduacao) {
        this.graduacao = graduacao;
    }

    /**
     * @return the cursoLeciona
     */
    public String getCursoLeciona() {
        return cursoLeciona;
    }

    /**
     * @param cursoLeciona the cursoLeciona to set
     */
    public void setCursoLeciona(String cursoLeciona) {
        this.cursoLeciona = cursoLeciona;
    }
}
