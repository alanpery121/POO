/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Funcionario;

/**
 *
 * @author ALAN
 */
public class Diretor extends Funcionario{
    private String administrar;
    private String fiscalizar;
    private String horarioAtendimento;

    /**
     * @return the administrar
     */
    public String getAdministrar() {
        return administrar;
    }

    /**
     * @param administrar the administrar to set
     */
    public void setAdministrar(String administrar) {
        this.administrar = administrar;
    }

    /**
     * @return the fiscalizar
     */
    public String getFiscalizar() {
        return fiscalizar;
    }

    /**
     * @param fiscalizar the fiscalizar to set
     */
    public void setFiscalizar(String fiscalizar) {
        this.fiscalizar = fiscalizar;
    }

    /**
     * @return the horarioAtendimento
     */
    public String getHorarioAtendimento() {
        return horarioAtendimento;
    }

    /**
     * @param horarioAtendimento the horarioAtendimento to set
     */
    public void setHorarioAtendimento(String horarioAtendimento) {
        this.horarioAtendimento = horarioAtendimento;
    }
}
