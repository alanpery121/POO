/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package faculdade;

/**
 *
 * @author ALAN
 */
public class UniLeao extends Faculdade{
    private String socios;
    private boolean PrediosAdaptados;
    private boolean financiamento;

    /**
     * @return the socios
     */
    public String getSocios() {
        return socios;
    }

    /**
     * @param socios the socios to set
     */
    public void setSocios(String socios) {
        this.socios = socios;
    }

    /**
     * @return the PrediosAdaptados
     */
    public boolean isPrediosAdaptados() {
        return PrediosAdaptados;
    }

    /**
     * @param PrediosAdaptados the PrediosAdaptados to set
     */
    public void setPrediosAdaptados(boolean PrediosAdaptados) {
        this.PrediosAdaptados = PrediosAdaptados;
    }

    /**
     * @return the financiamento
     */
    public boolean isFinanciamento() {
        return financiamento;
    }

    /**
     * @param financiamento the financiamento to set
     */
    public void setFinanciamento(boolean financiamento) {
        this.financiamento = financiamento;
    }
}
