/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package faculdade;

/**
 *
 * @author ALAN
 */
public class Faculdade {
    private String loalizacao;
    private String razaoSocial;
    private String cnpj;

    /**
     * @return the loalizacao
     */
    public String getLoalizacao() {
        return loalizacao;
    }

    /**
     * @param loalizacao the loalizacao to set
     */
    public void setLoalizacao(String loalizacao) {
        this.loalizacao = loalizacao;
    }

    /**
     * @return the razaoSocial
     */
    public String getRazaoSocial() {
        return razaoSocial;
    }

    /**
     * @param razaoSocial the razaoSocial to set
     */
    public void setRazaoSocial(String razaoSocial) {
        this.razaoSocial = razaoSocial;
    }

    /**
     * @return the cnpj
     */
    public String getCnpj() {
        return cnpj;
    }

    /**
     * @param cnpj the cnpj to set
     */
    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }
}
