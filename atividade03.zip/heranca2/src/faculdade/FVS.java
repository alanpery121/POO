/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package faculdade;

/**
 *
 * @author ALAN
 */
public class FVS extends Faculdade{
    private boolean cursoEAD;
    private boolean acoesSociais;
    private boolean cursosIntegrados;

    /**
     * @return the cursoEAD
     */
    public boolean isCursoEAD() {
        return cursoEAD;
    }

    /**
     * @param cursoEAD the cursoEAD to set
     */
    public void setCursoEAD(boolean cursoEAD) {
        this.cursoEAD = cursoEAD;
    }

    /**
     * @return the acoesSociais
     */
    public boolean isAcoesSociais() {
        return acoesSociais;
    }

    /**
     * @param acoesSociais the acoesSociais to set
     */
    public void setAcoesSociais(boolean acoesSociais) {
        this.acoesSociais = acoesSociais;
    }

    /**
     * @return the cursosIntegrados
     */
    public boolean isCursosIntegrados() {
        return cursosIntegrados;
    }

    /**
     * @param cursosIntegrados the cursosIntegrados to set
     */
    public void setCursosIntegrados(boolean cursosIntegrados) {
        this.cursosIntegrados = cursosIntegrados;
    }
}
